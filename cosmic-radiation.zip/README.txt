A Pen created at CodePen.io. You can find this one at https://codepen.io/cephalization/pen/GxLZeB.

 This pen generates patterns, or allows the user to draw patterns.  Features adjustable color width, pixel size, pen size, and more.